# Site2APK Builder

Beginner-friendly website-to-Android WebView APK prototype.

## Files
- `index.html`: mobile-friendly configuration page for GitHub Pages.
- `android/`: Android WebView wrapper project.
- `.github/workflows/build-apk.yml`: manual GitHub Actions workflow that builds a debug APK and uploads it as an artifact.

## Publish the website with GitHub Pages
1. Open repository **Settings → Pages**.
2. Under **Build and deployment**, select **Deploy from a branch**.
3. Select branch `main` and folder `/ (root)`, then Save.
4. Wait for Pages to publish; the URL will appear in Settings → Pages.

## Build an APK from an Android phone
1. Open **Actions → Build Android APK**.
2. If asked, enable workflows.
3. Press **Run workflow**.
4. Enter an HTTPS website URL, app name, and package ID (e.g. `com.example.mywebsiteapp`).
5. Start the workflow and wait for completion.
6. Open the completed run and download `site2apk-debug-apk`. Extract the ZIP to get the APK.

## Current limitations
- The static website cannot safely launch builds on its own. The user starts builds from GitHub Actions.
- The icon field previews an image only; custom icon embedding is not wired into this build yet.
- Output is a debug APK for testing, not a release-signed APK.
- Website restrictions, logins, and third-party services may affect WebView behavior.

Never place GitHub tokens, signing keys, or passwords in `index.html` or public files.
